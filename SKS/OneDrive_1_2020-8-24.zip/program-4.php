<?php
include "sucess_login-2.php";
$id=$_SESSION['m_id'];
$author=$_SESSION['m_name'];
require "config.php";
$sql="SELECT * FROM rad WHERE rad_author='$author' ORDER by rad_date_broadcast DESC";//搜索資料指令
$result=mysqli_query($link,$sql);//執行指令,並把結果存到result
$number_result=mysqli_num_rows($result);//符合條件的查詢結果的筆數


/*  查詢結轉成果array             */
for($i=0; $i<$number_result; $i++){
$arr[$i]=mysqli_fetch_array($result);
} 

$sql2="SELECT * FROM rad_prog WHERE rp_user_id='$id'";//搜索資料指令
$result2=mysqli_query($link,$sql2);//執行指令,並把結果存到result
$number_result2=mysqli_num_rows($result2);//符合條件的查詢結果的筆數


/*  查詢結轉成果array             */
for($ii=0; $ii<$number_result2; $ii++){
$arr2[$ii]=mysqli_fetch_array($result2);
} 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>無標題文件</title>
</head>

<body>
<p>
<table width="748" border="0" cellspacing="4" cellpadding="4">
  <tr>
    <td width="455" align="center" bgcolor="#FFFFFF"></td>
    <td width="158" bgcolor="#FFFFFF">&nbsp;</td>
    <td width="44" bgcolor="#FFFFFF">&nbsp;</td>
    <td width="39" bgcolor="#FFFFFF"><a href="program_insert.php">新增</a></td>
  </tr>
  <tr>
    <td width="455" align="center" bgcolor="#CCCCCC">節目名稱</td>
    <td width="158" bgcolor="#CCCCCC">主題名稱</td>
    <td width="44" bgcolor="#CCCCCC">&nbsp;</td>
    <td width="39" bgcolor="#CCCCCC">&nbsp;</td>
  </tr>
<?php
for($i=0; $i<$number_result; $i++){
	?>
<tr>
    <td bgcolor="#E3E3E3"><?php echo $arr[$i]['rad_title']?></td>
    <?php
    foreach ($arr2 as $key=>$row) {
		if($row['rp_id']==$arr[$i]['rad_main_title']){
	?>
    <td bgcolor="#E3E3E3"><?php echo $row['rp_name']?></td>
    <?php
		}
	}
	?>
    <td bgcolor="#E3E3E3"><a href="edit_prog.php?a=<?php echo $arr[$i]['rp_id']?>">修改</a></td>
    <td bgcolor="#E3E3E3"><a href="delete_prog.php?a=<?php echo $arr[$i]['rp_id']?>" onclick="if (confirm('確認刪除所選項目?')){return true;}else{event.stopPropagation(); event.preventDefault();};">刪除</a></td>
  </tr>
<?php
}
?>
</table>
</p>
</body>
</html>