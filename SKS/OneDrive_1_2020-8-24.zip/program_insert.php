<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>無標題文件</title>
<SCRIPT LANGUAGE="JavaScript" SRC="js/timepicker.js"></SCRIPT>


<link rel="stylesheet" href="//apps.bdimg.com/libs/jqueryui/1.10.4/css/jquery-ui.min.css">
  <script src="//apps.bdimg.com/libs/jquery/1.10.2/jquery.min.js"></script>
  <script src="//apps.bdimg.com/libs/jqueryui/1.10.4/jquery-ui.min.js"></script>
  <link rel="stylesheet" href="jqueryui/style.css">
  <script>
  $(function() {
    $( "#datepicker" ).datepicker({ 
        dateFormat: 'yy-mm-dd'
    });
    $( "#format" ).change(function() {
      var fromdate = $(this).val();
                alert(fromdate);
    });
  });
  </script>
</head>

<body>
<?php
include "sucess_login-2.php";
require "config.php";
$author=$_SESSION['m_name'];
$id=$_SESSION['m_id'];
mysqli_query($link, "SET CHARACTER SET UTF8");//解決亂碼
$sql = "SELECT DISTINCT rad_type FROM rad;";
$result=mysqli_query($link,$sql);//執行指令,並把結果存到result
$number_result=mysqli_num_rows($result);//符合條件的查詢結果的筆數

/*  查詢結轉成果array             */
for($i=0; $i<$number_result; $i++){
$arr[$i]=mysqli_fetch_array($result);
}
$sql2 = "SELECT * FROM rad_prog WHERE rp_user_id='$id' AND rp_old='0'";
$result2=mysqli_query($link,$sql2);//執行指令,並把結果存到result
$number_result2=mysqli_num_rows($result2);//符合條件的查詢結果的筆數

/*  查詢結轉成果array             */
for($ii=0; $ii<$number_result2; $ii++){
$arr2[$ii]=mysqli_fetch_array($result2);
}

?>
<form action="program_insert2.php" method="post" enctype="multipart/form-data" name="form1" id="form1">
<table width="793" border="0" cellspacing="4" cellpadding="4">
 	 <tr>
    <td bgcolor="#FFFFFF"></td>
    <td></td>
    <td bgcolor="#FFFFFF"></td>
    <td>從即時節目插入</td>
  </tr>
  <tr>
    <td colspan="4" align="center" bgcolor="#9CADC2">節目新增</td>
    </tr>
  <tr>
    <td width="174" bgcolor="#C5CFDC">節目主題</td>
    <td width="196"><select name="select" id="select">
      	<?php for($ii=0; $ii<$number_result2; $ii++){  ?>
        <option value="<?php echo $arr2[$ii]['rp_id'] ?>"><?php echo $arr2[$ii]['rp_name'] ?></option>
        
        <?php } ?>
      </select></td>
    <td width="185" bgcolor="#C5CFDC">主持人</td>
    <td width="186"><?php echo $author ?></td>
  </tr>
  <tr>
    <td bgcolor="#C5CFDC">標題</td>
    <td colspan="3">
      <input name="textfield" type="text" id="textfield" maxlength="200" /></td>
    </tr>
  <tr>
    <td valign="top" bgcolor="#C5CFDC">簡介</td>
    <td colspan="3">
      <textarea name="textarea" cols="69" rows="5" id="textarea"></textarea></td>
    </tr>
  <tr>
    <td bgcolor="#C5CFDC">播放日期</td>
    <td><label for="textfield2"></label>
      <input type="text" name="textfield2" id="datepicker"/></td>
    <td bgcolor="#C5CFDC">節目類別</td>
    <td><input type=text list=browsers name="prog_type">
		<datalist id=browsers >
        <?php for($i=0; $i<$number_result; $i++){?>
   		<option><?php echo $arr[$i]['rad_type']?></option>
   		
        <?php }?>
	  </datalist></td>
  </tr>
  <tr>
    <td bgcolor="#C5CFDC">播放時間</td>
    <td><input id='timepicker1' type='text' value='12:00 pm' name="time_start" size=8 maxlength=8 ONBLUR="validateDatePicker(this)">
    <IMG SRC="images/timepicker.gif" BORDER="0" ALT="Pick a Time!" ONCLICK="selectTime(this,timepicker1)" STYLE="cursor:hand">
    </td>
    <td bgcolor="#C5CFDC">結束時間</td>
    <td><input id='timepicker2' type='text' value='12:00 pm'  name="time_end"  size=8 maxlength=8 ONBLUR="validateDatePicker(this)">
    <IMG SRC="images/timepicker.gif" BORDER="0" ALT="Pick a Time!" ONCLICK="selectTime(this,timepicker2)" STYLE="cursor:hand">
    </td>
  </tr>
  <tr>
    <td bgcolor="#C5CFDC">參與來賓</td>
    <td colspan="3">
      <input type="text" name="textfield5" id="textfield5" />      <label for="select2"></label></td>
    </tr>
  <tr>
    <td bgcolor="#C5CFDC">語音檔上載</td>
    <td>
      <input type="file" name="fileField6" id="fileField6" /></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2" bgcolor="#9CADC2"><input type="reset" name="button" id="button" value="重設" /></td>
    <td colspan="2" align="right" bgcolor="#9CADC2"><input type="submit" name="button2" id="button2" value="送出" /></td>
    </tr>
</table>

</form>
</body>
</html>